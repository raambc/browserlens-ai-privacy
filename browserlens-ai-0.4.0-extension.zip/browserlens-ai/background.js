'use strict';
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
});
chrome.action.onClicked.addListener(async tab => {
  if (tab?.windowId !== undefined && chrome.sidePanel?.open) {
    try { await chrome.sidePanel.open({windowId:tab.windowId}); } catch (_) {}
  }
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'BL_PAGE_SNAPSHOT') {
    const tabId = sender.tab?.id;
    if (tabId == null) { sendResponse({ok:false}); return; }
    chrome.storage.local.get('pageSnapshots').then(({pageSnapshots={}})=>{
      pageSnapshots[String(tabId)] = {...msg.snapshot, tabId, receivedAt:new Date().toISOString()};
      return chrome.storage.local.set({pageSnapshots});
    }).then(()=>sendResponse({ok:true})).catch(()=>sendResponse({ok:false}));
    return true;
  }
});
