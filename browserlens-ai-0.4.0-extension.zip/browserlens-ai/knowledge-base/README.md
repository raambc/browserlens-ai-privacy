# BrowserLens AI Knowledge Base

`browserlens-knowledge-base.json` is a separately importable starter knowledge pack. In the extension, choose **Import knowledge base**.

The pack is intentionally labeled as a starter, not a complete history. Expand it with sourced records from official Chrome/Edge release notes, Chrome Platform Status, deprecation/removal notices, browser policy references, and historical default changes. Keep Chrome and Edge version ranges separate when their timelines differ. Never infer an effective policy value from a policy definition alone.

Each feature record should include lifecycle status and version dates when known. Each policy record should include supported platforms, documented defaults and version-specific changes when sourced, policy value/scope semantics, and a precise official source URL. Use `null` or `unknown` rather than inventing dates or defaults.
