(() => {
  'use strict';
  if (window.__browserLensStarted) return;
  window.__browserLensStarted = true;
  const MAX = 100;
  const events = [];
  const add = (kind, message, extra={}) => {
    try {
      events.push({kind, message:String(message||'').slice(0,1200), time:new Date().toISOString(), ...extra});
      if (events.length > MAX) events.splice(0, events.length-MAX);
    } catch (_) {}
  };
  window.addEventListener('error', e => {
    if (e.target && e.target !== window) {
      const el=e.target; const src=el.src || el.href || '';
      add('resource-error', `${el.tagName||'RESOURCE'} failed to load`, {resource:src.slice(0,1000)});
    } else add('javascript-error', e.message || 'Uncaught JavaScript error', {file:(e.filename||'').slice(0,1000), line:e.lineno||0, column:e.colno||0});
  }, true);
  window.addEventListener('unhandledrejection', e => {
    let reason='Unhandled promise rejection';
    try { reason = e.reason?.message || String(e.reason || reason); } catch (_) {}
    add('unhandled-rejection', reason);
  });
  const snapshot = () => {
    const perf = performance.getEntriesByType('resource').slice(-150).map(r => ({
      name:String(r.name||'').slice(0,1000), initiatorType:r.initiatorType||'', duration:Math.round(r.duration||0),
      transferSize:Number.isFinite(r.transferSize)?r.transferSize:null, responseEnd:Math.round(r.responseEnd||0)
    }));
    const failed = perf.filter(r => r.transferSize === 0 && !/^(data:|blob:|chrome-extension:|moz-extension:)/i.test(r.name));
    let forms=0, scripts=0, iframes=0;
    try { forms=document.forms.length; scripts=document.scripts.length; iframes=document.querySelectorAll('iframe').length; } catch (_) {}
    const payload = {
      url:location.href, title:document.title||'', capturedAt:new Date().toISOString(), readyState:document.readyState,
      userAgent:navigator.userAgent, language:navigator.language, platform:navigator.platform,
      viewport:{width:innerWidth,height:innerHeight}, page:{forms,scripts,iframes},
      errors:events.slice(), resources:perf, possibleZeroTransferResources:failed.slice(0,40),
      matchedFeatureCandidates:[],
      note:'Resource timing is indicative only; transferSize=0 does not prove a failed request. Cross-origin details may be restricted.'
    };
    try {
      chrome.storage.local.get('browserLensKB', ({browserLensKB}) => {
        const records = browserLensKB?.features || [];
        let sourceText = '';
        try { sourceText = Array.from(document.scripts).slice(0,250).map(s => `${s.src || ''}\n${s.src ? '' : (s.textContent || '').slice(0,250000)}`).join('\n').slice(0,1000000); } catch (_) {}
        let visibleText = '';
        try { visibleText = (document.body?.innerText || '').slice(0,150000); } catch (_) {}
        const haystack = `${location.href}\n${document.title}\n${sourceText}\n${visibleText}`.toLowerCase();
        const found = [];
        for (const f of records) {
          const terms = [...(f.identifiers || []), ...(f.aliases || [])].filter(x => typeof x === 'string' && x.trim().length > 2);
          const hits = terms.filter(term => haystack.includes(term.toLowerCase())).slice(0,8);
          if (hits.length) found.push({id:f.id, name:f.name, identifiers:hits});
          if (found.length >= 100) break;
        }
        payload.matchedFeatureCandidates = found;
        try { chrome.runtime.sendMessage({type:'BL_PAGE_SNAPSHOT',snapshot:payload},()=>void chrome.runtime.lastError); } catch (_) {}
      });
    } catch (_) {}
  };
  const schedule = () => setTimeout(snapshot, 350);
  if (document.readyState === 'complete') schedule(); else window.addEventListener('load', schedule, {once:true});
  const observer = new MutationObserver(() => { clearTimeout(window.__blSnapshotTimer); window.__blSnapshotTimer=setTimeout(snapshot,1500); });
  try { observer.observe(document.documentElement || document, {childList:true,subtree:true}); } catch (_) {}
  window.addEventListener('error', schedule, true); window.addEventListener('unhandledrejection', schedule);
  chrome.runtime.onMessage.addListener(msg => { if (msg?.type === 'BL_REQUEST_SNAPSHOT') schedule(); });
  setInterval(snapshot, 15000);
})();
